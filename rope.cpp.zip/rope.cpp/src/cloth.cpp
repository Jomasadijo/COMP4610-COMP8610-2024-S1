#include "include/cloth.h"
#include <iostream>

Cloth::Cloth(const Eigen::Vector3f& center, const Eigen::Vector2f& size, int num_nodes_x, int num_nodes_z, float node_mass, float k, float damping_factor)
    : center(center), size(size), num_nodes_x(num_nodes_x), num_nodes_z(num_nodes_z), node_mass(node_mass), spring_constant(k), damping_factor(damping_factor) {
    initializeMasses();
    linkSprings();
}

void Cloth::initializeMasses() {
    // Calculate the top left and bottom right corners of the cloth
    Eigen::Vector3f top_left = Eigen::Vector3f(center.x() - size.x() / 2, center.y(), center.z() - size.y() / 2);
    Eigen::Vector3f bottom_right = Eigen::Vector3f(center.x() + size.x() / 2, center.y(), center.z() + size.y() / 2);

    // Calculate the step sizes between nodes
    float step_x = size.x() / (num_nodes_x - 1);
    float step_z = size.y() / (num_nodes_z - 1);

    // Initialize the masses
    for (int i = 0; i < num_nodes_z; ++i) {
        for (int j = 0; j < num_nodes_x; ++j) {
            Eigen::Vector3f position = top_left + Eigen::Vector3f(j * step_x, 0, i * step_z);
            masses.emplace_back(position, node_mass, false); // All masses are not fixed by default
        }
    }
}

void Cloth::linkSprings() {
    int num_nodes = num_nodes_x * num_nodes_z;

    auto index = [this](int i, int j) {
        return i * num_nodes_x + j;
    };

    // Link structural, shear, and flexion springs
    for (int i = 0; i < num_nodes_z; ++i) {
        for (int j = 0; j < num_nodes_x; ++j) {
            int current = index(i, j);

            // Structural springs
            if (j < num_nodes_x - 1) {
                springs.emplace_back(current, index(i, j + 1), spring_constant); // Horizontal
            }
            if (i < num_nodes_z - 1) {
                springs.emplace_back(current, index(i + 1, j), spring_constant); // Vertical
            }

            // Shear springs
            if (j < num_nodes_x - 1 && i < num_nodes_z - 1) {
                springs.emplace_back(current, index(i + 1, j + 1), spring_constant); // Diagonal right-down
                if (j > 0) {
                    springs.emplace_back(current, index(i + 1, j - 1), spring_constant); // Diagonal left-down
                }
            }

            // Flexion springs
            if (j < num_nodes_x - 2) {
                springs.emplace_back(current, index(i, j + 2), spring_constant); // Horizontal
            }
            if (i < num_nodes_z - 2) {
                springs.emplace_back(current, index(i + 2, j), spring_constant); // Vertical
            }
        }
    }
}

void Cloth::simulateVerlet(float delta_t, Eigen::Vector3f gravity) {
    // Verlet integration with damping and gravity
    for (auto &mass : masses) {
        if (mass.is_fixed) continue;

        Eigen::Vector3f temp = mass.position;
        Eigen::Vector3f acceleration = mass.force / mass.mass + gravity;

        // Verlet integration formula with damping
        mass.position = mass.position + (1 - damping_factor) * (mass.position - mass.prev_position) + acceleration * delta_t * delta_t;
        mass.prev_position = temp;
    }

    // Apply spring forces
    for (auto &spring : springs) {
        Mass &m1 = masses[spring.mass1];
        Mass &m2 = masses[spring.mass2];

        Eigen::Vector3f direction = m1.position - m2.position;
        float length = direction.norm();
        Eigen::Vector3f force = spring_constant * (length - spring.rest_length) * direction.normalized();

        if (!m1.is_fixed) m1.force -= force;
        if (!m2.is_fixed) m2.force += force;
    }

    // Collision handling
    for (auto &mass : masses) {
        for (auto collider : colliders) {
            if (collider->checkCollision(mass)) {
                collider->resolveCollision(mass);
            }
        }
    }

    // Reset forces
    for (auto &mass : masses) {
        mass.force = Eigen::Vector3f(0, 0, 0);
    }
}

void Cloth::fixMass(int i) {
    if (i < 0 || i >= masses.size()) {
        std::cerr << "Invalid mass index" << std::endl;
        return;
    }
    masses[i].is_fixed = true;
}

void Cloth::addCollider(Collider* collider) {
    colliders.push_back(collider);
}
