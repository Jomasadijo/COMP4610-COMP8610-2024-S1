#include <iostream>
#include <vector>
#include "Eigen/Dense"

#include "include/rope.h"
#include "include/mass.h"
#include "include/spring.h"

Rope::Rope(Eigen::Vector3f start, Eigen::Vector3f end, int num_nodes, float node_mass, float k, float d, std::vector<int> fixed_nodes)
    : damping_factor(d) {
    initializeMasses(start, end, num_nodes, node_mass, fixed_nodes);
    linkSprings(k);
}

void Rope::initializeMasses(Eigen::Vector3f start, Eigen::Vector3f end, int num_nodes, float node_mass, std::vector<int> fixed_nodes) {
    // Calculate the step size between nodes
    Eigen::Vector3f step = (end - start) / (num_nodes - 1);

    // Initialize masses
    for (int i = 0; i < num_nodes; ++i) {
        Eigen::Vector3f position = start + step * i;
        Mass mass(position, node_mass, std::find(fixed_nodes.begin(), fixed_nodes.end(), i) != fixed_nodes.end());
        masses.push_back(mass);
    }
}

void Rope::linkSprings(float k) {
    int num_masses = masses.size();

    for (int i = 0; i < num_masses - 1; ++i) {
        springs.emplace_back(i, i + 1, k);
    }
}

void Rope::simulateEuler(float delta_t, Eigen::Vector3f gravity, IntegrationMethod method) {
    // Reset forces
    for (auto& mass : masses) {
        if (!mass.is_fixed) {
            mass.force = Eigen::Vector3f(0, 0, 0);
        }
    }

    // Apply gravity
    for (auto& mass : masses) {
        if (!mass.is_fixed) {
            mass.force += mass.mass * gravity;
        }
    }

    // Apply spring forces
    for (auto& spring : springs) {
        Mass& m1 = masses[spring.mass1];
        Mass& m2 = masses[spring.mass2];

        Eigen::Vector3f direction = m2.position - m1.position;
        float length = direction.norm();
        Eigen::Vector3f force = spring.k * (length - spring.rest_length) * direction.normalized();

        if (!m1.is_fixed) m1.force += force;
        if (!m2.is_fixed) m2.force -= force;
    }

    // Integrate using Euler's method
    for (auto& mass : masses) {
        if (!mass.is_fixed) {
            mass.velocity += delta_t * (mass.force / mass.mass);
            mass.position += delta_t * mass.velocity;
        }
    }
}

void Rope::simulateVerlet(float delta_t, Eigen::Vector3f gravity) {
    // Apply gravity
    for (auto& mass : masses) {
        if (!mass.is_fixed) {
            mass.force += mass.mass * gravity;
        }
    }

    // Apply spring forces
    for (auto& spring : springs) {
        Mass& m1 = masses[spring.mass1];
        Mass& m2 = masses[spring.mass2];

        Eigen::Vector3f direction = m2.position - m1.position;
        float length = direction.norm();
        Eigen::Vector3f force = spring.k * (length - spring.rest_length) * direction.normalized();

        if (!m1.is_fixed) m1.force += force;
        if (!m2.is_fixed) m2.force -= force;
    }

    // Integrate using Verlet's method
    for (auto& mass : masses) {
        if (!mass.is_fixed) {
            Eigen::Vector3f temp = mass.position;
            Eigen::Vector3f acceleration = mass.force / mass.mass + gravity;
            mass.position = mass.position + (1 - damping_factor) * (mass.position - mass.prev_position) + acceleration * delta_t * delta_t;
            mass.prev_position = temp;
        }
    }

    // Reset forces
    for (auto& mass : masses) {
        mass.force = Eigen::Vector3f(0, 0, 0);
    }
}
